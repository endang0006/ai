#Note :
#isinomor ganti dengan nomor kalian
#formatcoin ganti dengan format bot yang kalian inginkan
#contoh format coin ( btc, bch,ltc,zec,doge )
python bot.py +isinomor formatcoin && 
python bot.py +isinomor formatcoin && 
python bot.py +isinomor formatcoin && 
python bot.py +isinomor formatcoin && 
python bot.py +isinomor formatcoin && 